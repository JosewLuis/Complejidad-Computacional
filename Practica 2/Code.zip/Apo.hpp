#ifndef APO_HPP
#define APO_HPP
#include <cassert>
#include <algorithm>

using namespace std;

template <typename T> class Apo {

public:
    explicit Apo(size_t maxNodos);       // constructor
    void insertar(const T &e);
    void suprimir();
    const T &cima() const;
    bool vacio() const;
    Apo(const Apo<T> &A);                // ctor. de copia
    Apo<T>& operator =(const Apo<T>& A); // asignación de apo
    ~Apo();                              // destructor
    void insertar_min_max(const T& e);
    void eliminar_max();

private:
    typedef int nodo; // índice del vector// entre 0 y maxNodos-1
    T* nodos;      // vector de nodos
    int maxNodos;  // tamaño del vector
    nodo ultimo;   // último nodo del árbol

    nodo padre(nodo i) const { return (i-1)/2; }
    nodo hIzq(nodo i)  const { return 2*i+1; }
    nodo hDer(nodo i)  const { return 2*i+2; }
    void flotar(nodo i);
    void hundir(nodo i);
    int profundidad(nodo i)const;
    void flotar_min_max(nodo i);
    nodo mayor_nieto(nodo i);
};


template <typename T>inline Apo<T>::Apo(size_t maxNodos) :nodos(new T[maxNodos]),maxNodos(maxNodos),ultimo(-1){}  //APO vacio


template <typename T>inline const T& Apo<T>::cima() const
{
    assert(ultimo > -1);   // Apo no vacío
    return nodos[0];
}


template <typename T>inline bool Apo<T>::vacio() const{
    return (ultimo == -1);
}

template <typename T>inline void Apo<T>::insertar(const T& e)
{
    assert(ultimo < maxNodos-1);   // Apo no lleno
    nodos[++ultimo] = e;
    if (ultimo > 0)
        flotar(ultimo);   // Reordenar
}


template <typename T>void Apo<T>::flotar(nodo i)
{
    T e = nodos[i];

    while (i > 0 && e < nodos[padre(i)])
    {
        nodos[i] = nodos[padre(i)];
        i = padre(i);
    }
    nodos[i] = e;
}


template <typename T>inline void Apo<T>::suprimir()
{
    assert(ultimo > -1);   // Apo no vacío

    if (--ultimo > -1) // Apo no queda vacío
    {
        nodos[0] = nodos[ultimo+1];
        if (ultimo > 0)     // Quedan dos o más elementos.
            hundir(0);       // Reordenar
    }
}


template <typename T>void Apo<T>::hundir(nodo i){
    bool fin = false;
    T e = nodos[i];

    while (hIzq(i) <= ultimo && !fin) // hundir e
    {
        nodo hMin;   // hijo menor del nodo i
        if (hIzq(i) < ultimo && nodos[hDer(i)] < nodos[hIzq(i)])
            hMin = hDer(i);
        else
            hMin = hIzq(i);
        if (nodos[hMin] < e)
        { // subir el hijo menor
            nodos[i] = nodos[hMin];
            i = hMin;
        }
        else// e <= hijos
            fin = true;
    }
    nodos[i] = e;   // colocar e
}


template <typename T>inline Apo<T>::~Apo()
{
    delete[] nodos;
}


template <typename T>Apo<T>::Apo(const Apo<T>& A) :nodos(new T[A.maxNodos]),maxNodos(A.maxNodos),ultimo(A.ultimo)
{// copiar el vector
    for(nodo n = 0; n <= ultimo; n++)
        nodos[n] = A.nodos[n];
}



template <typename T>Apo<T>& Apo<T>::operator =(const Apo<T>& A)
{
    if (this != &A) // evitar autoasignación// Destruir el vector y crear uno nuevo si es necesario
    {    if (maxNodos != A.maxNodos)
        {
            delete[] nodos;
            maxNodos = A.maxNodos;
            nodos = new T[maxNodos];
        }
        ultimo = A.ultimo;// Copiar el vector
        for (nodo n = 0; n <= ultimo; n++)
            nodos[n] = A.nodos[n];
    }
    return *this;

}


template <typename T>void Apo<T>::insertar_min_max(const T& e)
{
    int prof;

    nodos[++ultimo] = e;
    prof = profundidad(ultimo);

    if(prof % 2 == 0)   // es par
    {
        if(e >= nodos[padre(padre(ultimo)) && e <= padre(ultimo)])            // abuelo <= e <= padre en el caso que se cumpla esto sale y no hace nada
        {}
        else
            flotar_min_max(ultimo);
    }
    else
    {
        if(e <= nodos[padre(padre(ultimo)) && e >= padre(ultimo)])               //padre <= e <= abuelo
        {}
        else
            flotar_min_max(ultimo);
    }


}


template <typename T>int Apo<T>::profundidad(const nodo i) const
{
    int cont;
    while(i > 0)
    {
        cont++;
        i = padre(i);
    }

    return cont;

}


template <typename T>void Apo<T>::flotar_min_max(nodo i)
{

    T e = nodos[i];

    if(profundidad(i) % 2 == 0)                     //nivel par
    {
        if(e <= nodos[padre(i)])
        {
            while(i > 0 && e < nodos[padre(padre(i))])         //mientras sea mayor que el abuelo
            {
                nodos[i] = nodos[padre(padre(i))];
                i = padre(padre(i));
            }
        }
        else
        {
            nodos[i] = nodos[padre(i)];
            nodos[padre(i)] = e;
            i = padre(i);

            while(i > 0 && e > nodos[padre(padre(i))])
            {
                nodos[i] = nodos[padre(padre(i))];
                i = padre(padre(i));
            }
        }
    }
    else                                        //nivel impar
    {
        if(e >= nodos[padre(i)])
        {
            while(i > 0 && e > nodos[padre(padre(i))])
            {
                nodos[i] = nodos[padre(padre(i))];
                i = padre(padre(i));
            }
        }

        else
        {
            nodos[i] = nodos[padre(i)];
            nodos[padre(i)] = e;
            i = padre(i);

            while(i > 0 && e < nodos[padre(padre(i))])         //mientras sea mayor que el abuelo
            {
                nodos[i] = nodos[padre(padre(i))];
                i = padre(padre(i));
            }
        }
    }

    nodos[i] = e;
}


template <typename T> void Apo<T>::eliminar_max()
{

    nodo max,nmax,i,hmax;
    T aux;

    if(nodos[1] > nodos[2])
        max = 1;
    else
        max = 2;

    nodos[max] = nodos[ultimo];
    ultimo--;

    i = max;
    while(i <= ultimo)
    {
        if(hIzq(hIzq(i)) < ultimo)
        {
            nmax = mayor_nieto(i);
            hmax = padre(nmax);
            if(nodos[i] < nodos[hmax])
            {
                aux = nodos[i];
                nodos[i] = nodos[hmax];
                nodos[hmax] = aux;
            }
            aux = nodos[i];
            nodos[i] = nodos[nmax];
            nodos[nmax] = aux;

        }
        else
        {
            if(nodos[hIzq(i)] > nodos[hDer(i)])
                hmax = hIzq(i);
            else
                hmax = hDer(i);

            if(nodos[i] < nodos[hmax])
            {
                aux = nodos[i];
                nodos[i] = nodos[hmax];
                nodos[hmax] = aux;
            }
        }
    }
}


#endif
