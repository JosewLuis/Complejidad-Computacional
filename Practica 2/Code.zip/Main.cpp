#include "grafoP.h"
#include <stdlib.h>
#include <ctime>

/* ***************************************************************************************************/
/* Done by: Jose Luis Cumbrera Sanchez ***************************************************************/
/* Subject: Computational Complexity *****************************************************************/
/* Guide: 1. You only have to change the three firsts global variables. ******************************/
/*        2. Change tam_grafo to change the size of the graph, u can put whatever you want. **********/
/*        3. Change obl_nodes to change the size of the mandatories nodes. ***************************/
/*        4. Change nonObli to change the size of the non-mandatories nodes to made the combinations.*/
/* IMPORTANT: obl_nodes+nonObli have to be <= tam_grafo **********************************************/
/* ***************************************************************************************************/

double tam_grafo=25;
double obl_nodes=10;
double nonObli=6;
double ciclos=0;

void Graph(GrafoP& P1, GrafoP& P, double T);
void Chases(GrafoP& P1);
void GraphK(GrafoP& P1, double k);
double fact(double n);

int main(){
    GrafoP P(tam_grafo);
    GrafoP P1(obl_nodes+nonObli);
    double i,j;
    //Inicializacion del Grafo:
    for(i=0;i<tam_grafo;i++){
        for(j=0;j<tam_grafo;j++){
            if(i==j){
                P[i][j]=INT_MAX;
            }else{
                P[i][j]=rand()%11; //Number between 0-10.
            }
        }
    }   //Graph inicialized.

    //Inicialization Graph P1:
    Graph(P1,P,obl_nodes+nonObli);
    //Start time:
    time_t start=time(NULL);
    Chases(P1);
    time_t end=time(NULL);
    //End time.
    time_t ttime=difftime(end,start);
    cout << ciclos << endl;
    cout << "In a total time: " << ttime << endl;
    return 0;
}

void Graph(GrafoP& P1, GrafoP& P, double Ta){
    double i,j;
    for(i=0;i<Ta;i++){
        for(j=0;j<Ta;j++){
            P1[i][j]=P[i][j];
        }
    }   //Graph inicialized.
}

void Chases(GrafoP& P1){
    double k;
    for(k=1;k<=nonObli;k++){
        GraphK(P1,k);
    }
    Prim(P1);
    ciclos++;
}

void GraphK(GrafoP& P1, double k){
    GrafoP P2(obl_nodes+k);
    Graph(P2,P1,obl_nodes+k);
    double i;
    for(i=0;i<fact(nonObli)/(fact(k)*(fact(nonObli-k)));i++){
        Prim(P2);
        ciclos++;
    }
}

double fact(double n){
   if ((n==0)||(n==1))
      return 1.;
   else
      return n*fact(n-1);
}
