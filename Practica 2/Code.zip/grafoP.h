#ifndef GRAFOP_H_
#define GRAFOP_H_
#include "Apo.hpp"
#include <vector>
#include <iostream>
using namespace std;

class GrafoP {
public:
    typedef int tCoste;
    typedef int vertice;
    struct arista {
        vertice orig, dest;
        tCoste coste;
        explicit arista(vertice v = vertice(), vertice w = vertice(),
                    tCoste c = tCoste()): orig(v), dest(w), coste(c) {}
        bool operator <(const arista& a) const {return coste < a.coste;}
    };
    const tCoste INFINITO = -1;
    explicit GrafoP(int n): costes(n, vector<tCoste>(n, INFINITO)) {}
    GrafoP(const GrafoP& G);
    //GrafoP(const GrafoP&& G);
    int numVert() const {return costes.size();}
    const vector<tCoste>& operator [](vertice v) const {return costes[v];}
    vector<tCoste>& operator [](vertice v) {return costes[v];}
    GrafoP& operator = (const GrafoP& G);
    int costeTotal() const;
    const vector<vector<tCoste> >& matriz() const {return costes;}
private:
    vector< vector<tCoste> > costes;
};

int GrafoP::costeTotal() const
{
    int t = 0;
    for (int i = 0; i < costes.size(); ++i)
        for(int j = i+1; j < costes.size(); ++j)
            if(costes[i][j] != INFINITO)
                t += costes[i][j];
    return t;
}

GrafoP::GrafoP(const GrafoP& G):costes(G.numVert(), vector<int>(G.numVert()))
{
   const size_t n = G.numVert();
   for (vertice i = 0; i < n; i++)
      for (vertice j = 0; j < n; j++)
         costes[i][j] = G[i][j];
}

GrafoP& GrafoP::operator=(const GrafoP& G)
{
    costes = G.matriz();
}

/*GrafoP::GrafoP(const GrafoP&& G):
   costes(G.numVert(), vector<int>(G.numVert()))
{
   const size_t n = G.numVert();
   for (vertice i = 0; i < n; i++)
      for (vertice j = 0; j < n; j++)
         costes[i][j] = G[i][j];
}*/


GrafoP Prim(const GrafoP G)
// Devuelve un �rbol generador de coste m�nimo
// de un grafo no dirigido ponderado y conexo G.
{
    typedef typename GrafoP::vertice vertice;
    typedef typename GrafoP::arista arista;
    const int INFINITO = G.INFINITO;
    arista a;
    const size_t n = G.numVert();
    GrafoP g(n);                // �rbol generador de coste m�nimo.
    vector<bool> U(n, false);           // Conjunto de v�rtices incluidos en g.
    Apo<arista> A(n*(n-1)/2-n+2);       // Aristas adyacentes al �rbol g ordenadas por costes.
    U[0] = true;                        // Incluir el primer v�rtice en U.
                                        // Introducir en el APO las aristas adyacentes al primer v�rtice.
    for (vertice v = 1; v < n; v++)
        if (G[0][v] != INFINITO){
            A.insertar(arista(0, v, G[0][v]));
            cout << G[0][v] << " ";
        }
    for (size_t i = 1; i <= n-1; i++) { // Seleccionar n-1 aristas.
                                        // Buscar una arista a de coste m�nimo que no forme un ciclo.
                                        // Nota: Las aristas en A tienen sus or�genes en el �rbol g.
        do {
            a = A.cima();
            A.suprimir();
        } while (U[a.dest]);    // a forma un ciclo (a.orig y a.dest
                                // est�n en U y en g).
                                // Incluir la arista a en el �rbol g y el nuevo v�rtice u en U.
        g[a.orig][a.dest] = g[a.dest][a.orig] = a.coste;
        vertice u = a.dest;
        U[u] = true;
                                // Introducir en el APO las aristas adyacentes al v�rtice u
                                // que no formen ciclos.
        for (vertice v = 0; v < n; v++)
            if (!U[v] && G[u][v] != INFINITO)
                A.insertar(arista(u, v, G[u][v]));
    }
    cout << endl;
    for(int i = 0; i < g.numVert(); ++i)
        for(int j = 0; j < g.numVert(); ++j)
            cout << i << " " << j << " " << g[i][j] << endl;

    return g;
}

#endif
